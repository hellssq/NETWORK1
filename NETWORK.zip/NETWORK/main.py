# нехуй пиздить код еблан
# пошел нохуй
import ctypes, os, time
import webbrowser

from colorama import Fore
from pystyle import Colorate, Colors, Center, Anime
from os import name, system
from pystyle import Colorate
import random
import requests
from banner import banner

db_url = "https://pastebin.com/pvdwzNwp"

while True:
    username = input("Введите имя пользователя: ")
    password = input("Введите пароль: ")

    response = requests.get(db_url)

    if response.status_code == 200:
        lines = response.text.split('\n')
        for line in lines:
                print("Авторизация успешна.")


                def init(autoreset):
                    pass


                init(autoreset=True)

                def print_banner(banner):
                    from pystyle import Anime, Colors, Colorate, Center


                from ctypes import wintypes

                hWnd = ctypes.windll.kernel32.GetConsoleWindow()

                user32 = ctypes.windll.user32
                screenWidth = user32.GetSystemMetrics(0)
                screenHeight = user32.GetSystemMetrics(1)
                rect = wintypes.RECT()
                ctypes.windll.user32.GetWindowRect(hWnd, ctypes.pointer(rect))

                windowWidth = rect.right - rect.left
                windowHeight = rect.bottom - rect.top

                newX = int((screenWidth - windowWidth) / 2)
                newY = int((screenHeight - windowHeight) / 2)

                ctypes.windll.user32.MoveWindow(hWnd, newX, newY, windowWidth, windowHeight, True)

                os.system('clear' if os.name == 'posix' else 'cls')

                intro = """               
                                                                                                                                                                                                      █
                                                                                                     




 ██████   █████ ██████████ ███████████ █████   ███   █████    ███████    ███████████   █████   ████
░░██████ ░░███ ░░███░░░░░█░█░░░███░░░█░░███   ░███  ░░███   ███░░░░░███ ░░███░░░░░███ ░░███   ███░ 
 ░███░███ ░███  ░███  █ ░ ░   ░███  ░  ░███   ░███   ░███  ███     ░░███ ░███    ░███  ░███  ███   
 ░███░░███░███  ░██████       ░███     ░███   ░███   ░███ ░███      ░███ ░██████████   ░███████    
 ░███ ░░██████  ░███░░█       ░███     ░░███  █████  ███  ░███      ░███ ░███░░░░░███  ░███░░███   
 ░███  ░░█████  ░███ ░   █    ░███      ░░░█████░█████░   ░░███     ███  ░███    ░███  ░███ ░░███  
 █████  ░░█████ ██████████    █████       ░░███ ░░███      ░░░███████░   █████   █████ █████ ░░████
░░░░░    ░░░░░ ░░░░░░░░░░    ░░░░░         ░░░   ░░░         ░░░░░░░    ░░░░░   ░░░░░ ░░░░░   ░░░░ 


       ENTER == START ENTER == START 
       ENTER == START ENTER == START                                                                         
 
                 """
                Anime.Fade(Center.Center(intro), Colors.blue_to_cyan, Colorate.Vertical, interval=0.045, enter=True)

                banner = """
                 
                                                                                                                                                                                                   █
                    

                                 ███╗   ██╗███████╗████████╗██╗    ██╗ ██████╗ ██████╗ ██╗  ██╗
                                 ████╗  ██║██╔════╝╚══██╔══╝██║    ██║██╔═══██╗██╔══██╗██║ ██╔╝
                                 ██╔██╗ ██║█████╗     ██║   ██║ █╗ ██║██║   ██║██████╔╝█████╔╝ 
                                 ██║╚██╗██║██╔══╝     ██║   ██║███╗██║██║   ██║██╔══██╗██╔═██╗ 
                                 ██║ ╚████║███████╗   ██║   ╚███╔███╔╝╚██████╔╝██║  ██║██║  ██╗
                                 ╚═╝  ╚═══╝╚══════╝   ╚═╝    ╚══╝╚══╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝
                """

                text = """
╔=====================================================================╗
║                                                                     ║ 
║ [1] DDos сайта                      [6] Пробив по id телеграм       ║
║ [2] Пробив по IP                    [7]VENATOR X (osint)            ║                                     
║ [3] Пробив по карте                 [8] Бомбер                      ║            
║ [4] Пробив по номеру телефона       [9] IP pinger                   ║
║ [5] Генератор паспортов            [10] Выйти из скрипта            ║
║ [11] Cнос ТГ                                                        ║
╚=====================================================================╝
                """
                print()
                print(Colorate.Vertical(Colors.blue_to_cyan, Center.XCenter(banner)))
                print(Colorate.Vertical(Colors.blue_to_cyan, Center.XCenter(text)))
                select = input(Colorate.Vertical(Colors.blue_to_cyan, Center.XCenter("[!] Введите функцию    ")))


                def get_number(путь_к_файлу, значение_поиска, цвета):
                    with open(путь_к_файлу, 'r', encoding='utf-8') as файл:
                        for строка in файл:
                            if значение_поиска in строка:
                                данные = строка.strip().split(';')
                                for индекс, значение in enumerate(данные, start=1):
                                    значение = значение.strip()
                                    if значение:
                                        print(f'{цвета["PURPLE"]}[{индекс}] {цвета["RESET"]}{значение}')


                def выбрать_случайную_строку(путь_к_файлу):
                    with open(путь_к_файлу, 'r', encoding='utf-8') as файл:
                        lines = файл.readlines()
                        random_string = random.choice(lines)
                        return random_string


                def сгенерировать_паспорт():
                    путь_к_вашему_файлу = 'PAS1k.txt'
                    случайная_строка = выбрать_случайную_строку(путь_к_вашему_файлу)
                    return случайная_строка


                while True:
                    os.system('cls' if os.name == 'nt' else 'clear')

                    for _ in range(4):
                        print()

                    COLOR_CODE = {
                        "PURPLE": "\033[35m",
                        "BOLD": "\033[01m",
                        "RESET": "\033[0m",
                        "GREEN": "\033[32m",
                        "YELLOW": Fore.YELLOW,
                        "RED": "\033[31m",
                        "CYAN": "\033[36m",
                        "BLUE": "\033[34m",
                    }

                    if select == '1':
                        from ddos import dos

                        dos()
                        input("Нажмите Enter, чтобы продолжить...")

                    elif select == '2':
                        import requests
                        import database
                        import sqlite3

                        def location(ip: str):
                            response = requests.get(f"http://ip-api.com/json/{ip}?lang=ru")
                            if response.status_code == 404:
                                print("Oops")
                            result = response.json()
                            if result["status"] == "fail":
                                return main("Enter the correct IP address")

                            record = []

                            for key, value in result.items():
                                record.append(value)
                                print(f"[{key.title()}]: {value}")
                            return tuple(record)


                        def main(start: str):
                            print(start)
                            ip = input("IP address: ")
                            try:
                                new_data = location(ip)
                                database.base(new_data)
                            except ValueError:
                                pass


                        if __name__ == "__main__":
                            main("Enter the IP address")



                            def base(data: tuple):
                                conn = sqlite3.connect("database.db")
                                cur = conn.cursor()
                                cur.execute("""CREATE TABLE IF NOT EXISTS location(
                                Status TEXT,
                                Country TEXT,
                                Countrycode TEXT,
                                Region TEXT,
                                Regionname TEXT,
                                City TEXT,
                                Zip INT,
                                Lat REAL,
                                Lon REAL,
                                Timezone TEXT,
                                Isp TEXT,
                                Org TEXT,
                                Auto_system TEXT,
                                Query TEXT);
                                """)
                                try:
                                    check = cur.execute(f"SELECT * FROM location WHERE Query=?", (data[-1],))
                                    if len(list(*check)) == 0:
                                        cur.execute("INSERT INTO location VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?);", data)
                                        conn.commit()
                                    else:
                                        print("Duplicate")
                                except TypeError:
                                    pass
                    elif select == '3':
                        from card import requests
                    elif select == '4':
                        from telefon import get_number

                        database_files = ['STR3ANGER(AKUMA BD).csv', 'STR3ANGER.csv', 'STR3ANGER(NATHACK_BD).csv', '']

                        search_value = input(
                            '{}Введите номер телефона (формат: 79999999999): {}'.format(COLOR_CODE["GREEN"],
                                                                                        COLOR_CODE["RESET"]))

                        for database_file in database_files:
                            get_number(database_file, search_value, COLOR_CODE)

                        input("Нажмите Enter, чтобы продолжить...")


                    elif select == '5':
                        количество_паспортов = min(1000, int(input(
                            "Введите количество паспортов для генерации (максимум 1000): ")))
                        for _ in range(количество_паспортов):
                            сгенерированный_паспорт = сгенерировать_паспорт()
                            print(сгенерированный_паспорт)
                    elif select == '6':
                        from telefon import get_number

                        database_files = ['STR3ANGER(AKUMA BD).csv', 'STR3ANGER.csv', 'STR3ANGER(NATHACK_BD).csv']

                        search_value = input(
                            '{}Введите id telegram: {}'.format(COLOR_CODE["GREEN"], COLOR_CODE["RESET"]))

                        for database_file in database_files:
                            id(database_file, search_value, COLOR_CODE)

                        input("Нажмите Enter, чтобы продолжить...")

                    elif select == '7':
                        with open('venatorx.txt', 'r') as file:
                            data = file.read()


                    elif select == '8':
                        import requests

                        check = requests.get("https://github.com/")
                        print(check)

                        phone = input("Введите номер обидчика в формате +79999999999: ")
                        try:
                            requests.post('https://belkacar.ru/get-confirmation-code', data={'phone': phone})
                            print('Сообщение отправлено успешно.')
                        except:
                            print('Ошибка при отправке сообщения.')
                    # если у вас пустая строчка то сообщение отправлено

                    elif select == '9':
                        print(Colorate.Horizontal(Colors.blue_to_cyan, "[!] Введите IP! "))
                        IPATTACK = input()
                        time.sleep(2)
                        while True:
                            print(
                                Colorate.Horizontal(Colors.rainbow, ("Разрушаю IP " + IPATTACK))
                            )
                            time.sleep(1)
                            print(
                                Colorate.Horizontal(Colors.rainbow, ("Процесс... " + IPATTACK))
                            )
                    elif select == '10':
                        exit()
                    elif select == '11':
                      webbrowser.open('https: // telegra.ph / Snos - TGK - LOL - QWQ - 12 - 13')


                    else:
                        print(f'{COLOR_CODE["RED"]}Неверный выбор, попробуйте снова!{COLOR_CODE["RESET"]}')
